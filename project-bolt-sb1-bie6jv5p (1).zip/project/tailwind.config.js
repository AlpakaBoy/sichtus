/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#fff8e6',  // Light honey
          100: '#ffefcc',  // Soft honey
          200: '#ffe099',  // Warm honey
          300: '#ffd166',  // Golden honey
          400: '#ffc233',  // Rich honey
          500: '#ffb300',  // Pure honey
          600: '#cc8f00',  // Dark honey
          700: '#996b00',  // Deep honey
          800: '#664700',  // Brown honey
          900: '#332300',  // Dark brown honey
        },
        secondary: {
          50: '#f9f6f3',  // Light bear tan
          100: '#f3ece6',  // Soft bear tan
          200: '#e6d9cc',  // Warm bear tan
          300: '#d9c6b3',  // Bear tan
          400: '#ccb399',  // Rich bear tan
          500: '#bfa080',  // Pure bear tan
          600: '#997f66',  // Dark bear tan
          700: '#735f4c',  // Deep bear tan
          800: '#4c3f33',  // Brown bear
          900: '#261f19',  // Dark brown bear
        },
        wood: {
          50: '#faf6f3',
          100: '#f5ece6',
          200: '#ebd9cc',
          300: '#e0c6b3',
          400: '#d6b399',
          500: '#cca080',
          600: '#a37f66',
          700: '#7a5f4c',
          800: '#513f33',
          900: '#291f19',
        },
      },
      fontFamily: {
        sans: [
          'Inter var',
          'system-ui',
          '-apple-system',
          'BlinkMacSystemFont',
          'Segoe UI',
          'Roboto',
          'Helvetica Neue',
          'Arial',
          'Noto Sans',
          'sans-serif',
        ],
      },
      animation: {
        'bounce-slow': 'bounce 3s infinite',
        'float': 'float 6s ease-in-out infinite',
        'wave': 'wave 2s linear infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-20px)' },
        },
        wave: {
          '0%': { transform: 'rotate(0.0deg)' },
          '10%': { transform: 'rotate(14.0deg)' },
          '20%': { transform: 'rotate(-8.0deg)' },
          '30%': { transform: 'rotate(14.0deg)' },
          '40%': { transform: 'rotate(-4.0deg)' },
          '50%': { transform: 'rotate(10.0deg)' },
          '60%': { transform: 'rotate(0.0deg)' },
          '100%': { transform: 'rotate(0.0deg)' },
        },
      },
    },
  },
  plugins: [],
};