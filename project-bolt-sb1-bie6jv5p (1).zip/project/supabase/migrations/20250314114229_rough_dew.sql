/*
  # Initial Schema Setup for SichtBär

  1. New Tables
    - `posts`: Stores all social media posts
    - `analytics`: Stores analytics data
    - `chat_history`: Stores AI assistant chat history
    - `seo_reports`: Stores SEO analysis results

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to access their own data

  3. Notes
    - All tables include created_at and updated_at timestamps
    - Foreign key constraints ensure data integrity
    - Indexes added for frequently queried columns
*/

-- Posts table
CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text,
  platform text NOT NULL,
  scheduled_for timestamptz,
  status text NOT NULL DEFAULT 'draft',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_posts_user_id ON posts(user_id);
CREATE INDEX idx_posts_scheduled_for ON posts(scheduled_for);

-- Analytics table
CREATE TABLE IF NOT EXISTS analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  date date NOT NULL,
  platform text NOT NULL,
  reach integer DEFAULT 0,
  engagement integer DEFAULT 0,
  shares integer DEFAULT 0,
  followers integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_analytics_user_date ON analytics(user_id, date);

-- Chat history table
CREATE TABLE IF NOT EXISTS chat_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  message text NOT NULL,
  is_assistant boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_chat_history_user_id ON chat_history(user_id);

-- SEO reports table
CREATE TABLE IF NOT EXISTS seo_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  url text NOT NULL,
  analysis jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_seo_reports_user_id ON seo_reports(user_id);

-- Enable Row Level Security
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE seo_reports ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can manage their own posts"
  ON posts
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can manage their own analytics"
  ON analytics
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can manage their own chat history"
  ON chat_history
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can manage their own SEO reports"
  ON seo_reports
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create functions for updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_posts_updated_at
  BEFORE UPDATE ON posts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_seo_reports_updated_at
  BEFORE UPDATE ON seo_reports
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();