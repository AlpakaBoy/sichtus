import React from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp,
  Users,
  Share2,
  MessageSquare,
  BarChart2,
  Activity,
  ArrowUp,
  ArrowDown
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { useAnalyticsStore } from '../store/analyticsStore';

export function Analytics() {
  const { data } = useAnalyticsStore();

  const metrics = [
    {
      name: 'Total Reach',
      value: Object.values(data).reduce((sum, platform) => sum + platform.reach, 0).toLocaleString(),
      change: '+14.3%',
      icon: Users,
      changeType: 'increase'
    },
    {
      name: 'Engagement',
      value: `${(Object.values(data).reduce((sum, platform) => sum + platform.engagement, 0) / Object.keys(data).length).toFixed(1)}%`,
      change: '+7.8%',
      icon: MessageSquare,
      changeType: 'increase'
    },
    {
      name: 'Shares',
      value: Object.values(data).reduce((sum, platform) => sum + platform.shares, 0).toLocaleString(),
      change: '+11.2%',
      icon: Share2,
      changeType: 'increase'
    },
    {
      name: 'Growth Rate',
      value: `${(Object.values(data).reduce((sum, platform) => sum + platform.growth, 0) / Object.keys(data).length).toFixed(1)}%`,
      change: '+2.1%',
      icon: TrendingUp,
      changeType: 'increase'
    }
  ];

  const platformColors = {
    Instagram: '#E1306C',
    Twitter: '#1DA1F2',
    LinkedIn: '#0A66C2',
    Facebook: '#4267B2'
  };

  return (
    <div>
      <div className="pb-5 border-b border-wood-700">
        <h3 className="text-3xl font-bold text-primary-300">
          Analytics
        </h3>
      </div>

      <div className="mt-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {metrics.map((metric) => (
            <motion.div
              key={metric.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-wood-800 rounded-lg p-6"
            >
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-primary-500/20">
                  <metric.icon className="h-6 w-6 text-primary-400" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-wood-300">{metric.name}</p>
                  <div className="flex items-baseline">
                    <p className="text-2xl font-semibold text-wood-100">{metric.value}</p>
                    <span className={`ml-2 text-sm font-medium ${
                      metric.changeType === 'increase' ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {metric.changeType === 'increase' ? (
                        <ArrowUp className="inline h-4 w-4" />
                      ) : (
                        <ArrowDown className="inline h-4 w-4" />
                      )}
                      {metric.change}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Charts */}
        <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-2">
          {/* Platform Performance */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-wood-800 rounded-lg shadow-lg"
          >
            <div className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <BarChart2 className="h-6 w-6 text-primary-400" />
                <h4 className="text-xl font-semibold text-wood-100">Platform Performance</h4>
              </div>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={Object.entries(data).map(([platform, stats]) => ({
                        name: platform,
                        value: stats.engagement * stats.reach / 100
                      }))}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {Object.keys(data).map((platform) => (
                        <Cell
                          key={platform}
                          fill={platformColors[platform as keyof typeof platformColors]}
                        />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </motion.div>

          {/* Engagement Trends */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-wood-800 rounded-lg shadow-lg"
          >
            <div className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <Activity className="h-6 w-6 text-primary-400" />
                <h4 className="text-xl font-semibold text-wood-100">Engagement Trends</h4>
              </div>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={[
                      { name: 'Mon', Instagram: 4000, Twitter: 2400, LinkedIn: 2400 },
                      { name: 'Tue', Instagram: 3000, Twitter: 1398, LinkedIn: 2210 },
                      { name: 'Wed', Instagram: 2000, Twitter: 9800, LinkedIn: 2290 },
                      { name: 'Thu', Instagram: 2780, Twitter: 3908, LinkedIn: 2000 },
                      { name: 'Fri', Instagram: 1890, Twitter: 4800, LinkedIn: 2181 },
                      { name: 'Sat', Instagram: 2390, Twitter: 3800, LinkedIn: 2500 },
                      { name: 'Sun', Instagram: 3490, Twitter: 4300, LinkedIn: 2100 }
                    ]}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="name" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: 'none',
                        borderRadius: '0.5rem',
                        color: '#F3F4F6'
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="Instagram"
                      stroke="#E1306C"
                      fill="#E1306C"
                      fillOpacity={0.2}
                    />
                    <Area
                      type="monotone"
                      dataKey="Twitter"
                      stroke="#1DA1F2"
                      fill="#1DA1F2"
                      fillOpacity={0.2}
                    />
                    <Area
                      type="monotone"
                      dataKey="LinkedIn"
                      stroke="#0A66C2"
                      fill="#0A66C2"
                      fillOpacity={0.2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}