import React from 'react';
import { Calendar as CalendarIcon, Plus, List, CircleDot as DragHandleDots2 } from 'lucide-react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { useContentStore, Draft } from '../store/contentStore';

function SortablePost({ post }: { post: Draft }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition
  } = useSortable({ id: post.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition
  };

  const getPlatformColor = (platform: string) => {
    switch (platform) {
      case 'Instagram':
        return 'bg-pink-500/20 text-pink-400';
      case 'Twitter':
        return 'bg-blue-500/20 text-blue-400';
      case 'LinkedIn':
        return 'bg-blue-600/20 text-blue-600';
      case 'Facebook':
        return 'bg-blue-500/20 text-blue-500';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="bg-wood-700 rounded-lg p-4 cursor-move group hover:bg-wood-600 transition-all duration-200"
      {...attributes}
      {...listeners}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <DragHandleDots2 className="h-5 w-5 text-wood-400 mr-3" />
          <div>
            <h4 className="text-wood-100 font-medium">{post.title}</h4>
            <div className="flex items-center gap-2 mt-1">
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getPlatformColor(post.platform)}`}>
                {post.platform}
              </span>
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                post.status === 'draft'
                  ? 'bg-yellow-500/20 text-yellow-400'
                  : post.status === 'scheduled'
                  ? 'bg-primary-500/20 text-primary-400'
                  : 'bg-green-500/20 text-green-400'
              }`}>
                {post.status}
              </span>
            </div>
          </div>
        </div>
      </div>
      <p className="mt-2 text-wood-300 text-sm line-clamp-2">{post.content}</p>
      {post.scheduledFor && (
        <p className="mt-2 text-wood-400 text-xs">
          Scheduled for: {new Date(post.scheduledFor).toLocaleString()}
        </p>
      )}
    </div>
  );
}

export function ContentPlanning() {
  const { drafts, reorderDrafts, scheduleDraft } = useContentStore();
  
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event: any) => {
    const { active, over } = event;

    if (active.id !== over.id) {
      const oldIndex = drafts.findIndex((draft) => draft.id === active.id);
      const newIndex = drafts.findIndex((draft) => draft.id === over.id);
      reorderDrafts(arrayMove(drafts, oldIndex, newIndex));
    }
  };

  const handleEventDrop = (info: any) => {
    const draftId = info.event.id;
    const newDate = info.event.start.toISOString();
    scheduleDraft(draftId, newDate);
  };

  const handleDateClick = (info: any) => {
    // Open a modal or prompt to create a new post
    console.log('Date clicked:', info.dateStr);
  };

  return (
    <div>
      <div className="pb-5 border-b border-wood-700">
        <h3 className="text-3xl font-bold text-primary-300">
          Content Planning
        </h3>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Calendar View */}
        <div className="lg:col-span-2">
          <div className="bg-wood-800 shadow rounded-lg">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center">
                  <CalendarIcon className="h-6 w-6 text-primary-400" />
                  <h4 className="ml-2 text-xl font-semibold text-wood-100">Content Calendar</h4>
                </div>
                <button className="bg-primary-500 text-wood-900 px-4 py-2 rounded-lg hover:bg-primary-400 transition-colors flex items-center">
                  <Plus className="h-5 w-5 mr-2" />
                  New Post
                </button>
              </div>
              <div className="content-calendar">
                <FullCalendar
                  plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
                  initialView="dayGridMonth"
                  headerToolbar={{
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek'
                  }}
                  editable={true}
                  droppable={true}
                  eventDrop={handleEventDrop}
                  dateClick={handleDateClick}
                  events={drafts
                    .filter(draft => draft.scheduledFor)
                    .map(draft => ({
                      id: draft.id,
                      title: draft.title,
                      start: draft.scheduledFor,
                      backgroundColor: draft.platform === 'Instagram' ? '#E1306C' :
                                     draft.platform === 'Twitter' ? '#1DA1F2' :
                                     draft.platform === 'LinkedIn' ? '#0077B5' : '#4267B2',
                      extendedProps: {
                        platform: draft.platform,
                        content: draft.content
                      }
                    }))}
                  eventContent={(eventInfo) => (
                    <div className="p-1">
                      <div className="text-xs font-medium">{eventInfo.event.title}</div>
                      <div className="text-xs opacity-75">{eventInfo.event.extendedProps.platform}</div>
                    </div>
                  )}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Posts List */}
        <div>
          <div className="bg-wood-800 shadow rounded-lg">
            <div className="p-6">
              <div className="flex items-center mb-6">
                <List className="h-6 w-6 text-primary-400" />
                <h4 className="ml-2 text-xl font-semibold text-wood-100">Content Queue</h4>
              </div>
              <DndContext
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragEnd={handleDragEnd}
              >
                <SortableContext
                  items={drafts.map(draft => draft.id)}
                  strategy={verticalListSortingStrategy}
                >
                  <div className="space-y-4">
                    {drafts.map((draft) => (
                      <SortablePost key={draft.id} post={draft} />
                    ))}
                  </div>
                </SortableContext>
              </DndContext>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}