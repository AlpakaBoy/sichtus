import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  PenTool,
  Send,
  Instagram,
  Twitter,
  Linkedin,
  Facebook,
  GripVertical,
  Plus,
  Trash2,
  Calendar
} from 'lucide-react';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { useContentStore, Draft } from '../store/contentStore';
import { useNavigate } from 'react-router-dom';

function SortableDraft({ draft }: { draft: Draft }) {
  const navigate = useNavigate();
  const { deleteDraft } = useContentStore();
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: draft.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'Instagram':
        return <Instagram className="h-5 w-5 text-pink-400" />;
      case 'Twitter':
        return <Twitter className="h-5 w-5 text-blue-400" />;
      case 'LinkedIn':
        return <Linkedin className="h-5 w-5 text-blue-600" />;
      case 'Facebook':
        return <Facebook className="h-5 w-5 text-blue-500" />;
      default:
        return null;
    }
  };

  const handleSchedule = () => {
    navigate('/dashboard/content');
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="bg-wood-800 rounded-lg p-4 cursor-move group hover:bg-wood-700 transition-colors"
      {...attributes}
      {...listeners}
    >
      <div className="flex items-start gap-3">
        <GripVertical className="h-5 w-5 text-wood-400 flex-shrink-0 mt-1" />
        <div className="flex-grow">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {getPlatformIcon(draft.platform)}
              <h3 className="text-lg font-medium text-wood-100">{draft.title}</h3>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={handleSchedule}
                className="text-wood-400 hover:text-primary-400 transition-colors"
              >
                <Calendar className="h-5 w-5" />
              </button>
              <button 
                onClick={() => deleteDraft(draft.id)}
                className="text-wood-400 hover:text-red-400 transition-colors"
              >
                <Trash2 className="h-5 w-5" />
              </button>
            </div>
          </div>
          <p className="mt-2 text-wood-300">{draft.content}</p>
          <div className="mt-2 text-sm text-wood-400">
            Created {new Date(draft.createdAt).toLocaleDateString()}
          </div>
          {draft.scheduledFor && (
            <div className="mt-1 text-sm text-primary-400">
              Scheduled for {new Date(draft.scheduledFor).toLocaleString()}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function ContentProduction() {
  const [prompt, setPrompt] = useState('');
  const [selectedPlatform, setSelectedPlatform] = useState('Instagram');
  const { drafts, addDraft, reorderDrafts } = useContentStore();

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const platforms = [
    { name: 'Instagram', icon: Instagram },
    { name: 'Twitter', icon: Twitter },
    { name: 'LinkedIn', icon: Linkedin },
    { name: 'Facebook', icon: Facebook }
  ];

  const handleDragEnd = (event: any) => {
    const { active, over } = event;

    if (active.id !== over.id) {
      const oldIndex = drafts.findIndex((draft) => draft.id === active.id);
      const newIndex = drafts.findIndex((draft) => draft.id === over.id);
      reorderDrafts(arrayMove(drafts, oldIndex, newIndex));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    const newDraft: Draft = {
      id: Math.random().toString(36).substr(2, 9),
      title: `New ${selectedPlatform} Post`,
      content: prompt,
      platform: selectedPlatform,
      priority: drafts.length + 1,
      createdAt: new Date().toISOString(),
      scheduledFor: null,
      status: 'draft'
    };

    addDraft(newDraft);
    setPrompt('');
  };

  return (
    <div>
      <div className="pb-5 border-b border-wood-700">
        <h3 className="text-3xl font-bold text-primary-300">
          Content Production
        </h3>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-3">
        {/* AI Content Generation */}
        <div className="lg:col-span-2">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-wood-800 rounded-lg p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <PenTool className="h-6 w-6 text-primary-400" />
              <h4 className="text-xl font-semibold text-wood-100">
                Create New Content
              </h4>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-wood-300 mb-2">
                  Platform
                </label>
                <div className="flex gap-2">
                  {platforms.map((platform) => (
                    <button
                      key={platform.name}
                      type="button"
                      onClick={() => setSelectedPlatform(platform.name)}
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                        selectedPlatform === platform.name
                          ? 'bg-primary-500 text-wood-900'
                          : 'bg-wood-700 text-wood-300 hover:bg-wood-600'
                      }`}
                    >
                      <platform.icon className="h-5 w-5" />
                      {platform.name}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-wood-300 mb-2">
                  What would you like to create?
                </label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={4}
                  className="w-full bg-wood-700 text-wood-100 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                  placeholder="Describe what kind of content you want to create..."
                />
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="flex items-center gap-2 px-6 py-2 bg-primary-500 text-wood-900 rounded-lg hover:bg-primary-400 transition-colors"
                >
                  <Send className="h-5 w-5" />
                  Generate Content
                </button>
              </div>
            </form>
          </motion.div>
        </div>

        {/* Drafts */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-wood-800 rounded-lg p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Plus className="h-6 w-6 text-primary-400" />
                <h4 className="text-xl font-semibold text-wood-100">
                  Content Drafts
                </h4>
              </div>
            </div>

            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
            >
              <SortableContext
                items={drafts.map(draft => draft.id)}
                strategy={verticalListSortingStrategy}
              >
                <div className="space-y-4">
                  {drafts.map((draft) => (
                    <SortableDraft key={draft.id} draft={draft} />
                  ))}
                </div>
              </SortableContext>
            </DndContext>
          </motion.div>
        </div>
      </div>
    </div>
  );
}