import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ChevronRight, BarChart2, Users, Zap, Shield, Send, ChevronDown } from 'lucide-react';
import Typewriter from 'typewriter-effect';

export function LandingPage() {
  const [chatMessage, setChatMessage] = useState('');
  const [chatHistory, setChatHistory] = useState([
    { type: 'bot', text: 'Hey! 👋 Ich bin der Sicht-Bär! Was möchtest du über unsere App wissen?' }
  ]);
  const featuresRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatHistory]);

  const scrollToFeatures = () => {
    featuresRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;

    setChatHistory(prev => [...prev, { type: 'user', text: chatMessage }]);

    setTimeout(() => {
      let response = "Das ist eine super Frage! ";
      if (chatMessage.toLowerCase().includes('preis')) {
        response += "Wir bieten einen kostenlosen Testzeitraum an. Danach geht's schon ab 9,99€ pro Monat los!";
      } else if (chatMessage.toLowerCase().includes('funktionen')) {
        response += "Mit mir kannst du alle deine Social Media Kanäle verwalten, Beiträge planen und tolle Analysen erstellen!";
      } else {
        response += "Lass uns zusammen deine Social Media Präsenz auf das nächste Level bringen! Was interessiert dich besonders?";
      }
      setChatHistory(prev => [...prev, { type: 'bot', text: response }]);
    }, 1000);

    setChatMessage('');
  };

  const features = [
    {
      icon: BarChart2,
      title: '📈 Smarte Insights',
      description: 'Verstehe deine Performance spielend leicht - keine Raketenwissenschaft!'
    },
    {
      icon: Users,
      title: '🎯 Zielgruppen-Check',
      description: 'Lerne deine Community richtig kennen und wachse gemeinsam'
    },
    {
      icon: Zap,
      title: '⚡ Automatisierung',
      description: 'Lass die Routine-Arbeit von mir machen, während du kreativ sein kannst'
    },
    {
      icon: Shield,
      title: '🔒 Sicher ist sicher',
      description: 'Deine Daten sind bei mir so sicher wie in Bärenhöhle'
    }
  ];

  return (
    <div className="bg-wood-900 text-wood-100">
      {/* Hero Section */}
      <div className="min-h-screen relative overflow-hidden flex flex-col">
        <div className="flex-grow">
          <div className="max-w-7xl mx-auto h-full">
            <div className="relative z-10 h-full flex items-center pb-8 sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
              <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-20">
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8 }}
                  className="sm:text-center lg:text-left"
                >
                  <h1 className="text-4xl tracking-tight font-extrabold sm:text-5xl md:text-6xl">
                    <span className="block text-primary-300">Hey, ich bin der</span>
                    <div className="flex items-center">
                      <span className="block text-primary-500">Sicht-Bär!</span>
                      <img
                        src="https://i.imgur.com/z2v9SfQ.png"
                        alt="Sicht-Bär Logo"
                        className="h-16 w-16 ml-2 animate-wave"
                      />
                    </div>
                  </h1>
                  <div className="h-[80px] mt-8 text-xl text-wood-300 sm:mt-10 sm:text-2xl md:mt-12 md:text-2xl">
                    <div className="w-full sm:w-[500px] lg:w-[600px]">
                      <Typewriter
                        options={{
                          strings: [
                            "Lass uns deine Social Media Story rocken! 🚀",
                            "Gemeinsam machen wir dich zum Social Media Star! ⭐",
                            "Ich bin dein Social Media Buddy! 🤝"
                          ],
                          autoStart: true,
                          loop: true,
                          deleteSpeed: 50,
                          delay: 80
                        }}
                      />
                    </div>
                  </div>
                  <div className="mt-10 sm:mt-12 sm:flex sm:justify-center lg:justify-start">
                    <div className="rounded-md shadow">
                      <Link
                        to="/login"
                        className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-wood-900 bg-primary-500 hover:bg-primary-400 md:py-4 md:text-lg md:px-10 transform transition-transform duration-300 hover:scale-105"
                      >
                        Los geht's! 🚀
                      </Link>
                    </div>
                    <div className="mt-3 sm:mt-0 sm:ml-3">
                      <button
                        onClick={scrollToFeatures}
                        className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-primary-300 bg-wood-800 hover:bg-wood-700 md:py-4 md:text-lg md:px-10 transform transition-transform duration-300 hover:scale-105"
                      >
                        Zeig mir mehr! 👀
                      </button>
                    </div>
                  </div>
                </motion.div>
              </main>
            </div>
          </div>

          {/* Bear Image Section */}
          <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
            <motion.div 
              className="relative w-full h-full min-h-[500px] flex flex-col items-center justify-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="w-full h-full max-w-2xl relative">
                <img
                  src="https://i.imgur.com/XxfPmtQ.png"
                  alt="Sicht-Bär Character"
                  className="w-full h-auto max-w-md mx-auto"
                  style={{
                    filter: 'drop-shadow(0 0 20px rgba(255, 179, 0, 0.3))'
                  }}
                />
                
                <div className="speech-bubble">
                  <form onSubmit={handleChatSubmit} className="flex gap-2">
                    <input
                      type="text"
                      value={chatMessage}
                      onChange={(e) => setChatMessage(e.target.value)}
                      placeholder="Frag mich was!"
                      className="flex-1 bg-wood-700 text-wood-100 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                    <button
                      type="submit"
                      className="bg-primary-500 text-wood-900 rounded-lg p-2 hover:bg-primary-400 transition-colors"
                    >
                      <Send className="w-5 h-5" />
                    </button>
                  </form>
                  
                  <div ref={chatContainerRef} className="chat-container">
                    <AnimatePresence>
                      {chatHistory.map((msg, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0 }}
                          className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`rounded-lg px-4 py-2 max-w-[80%] ${
                              msg.type === 'user'
                                ? 'bg-primary-500 text-wood-900'
                                : 'bg-wood-700 text-wood-100'
                            }`}
                          >
                            {msg.text}
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
        
        {/* Scroll indicator */}
        <motion.div 
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 cursor-pointer"
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          onClick={scrollToFeatures}
        >
          <ChevronDown className="w-8 h-8 text-primary-300" />
        </motion.div>
      </div>

      {/* Features Section */}
      <motion.div 
        ref={featuresRef}
        className="min-h-screen bg-wood-800 py-24 flex items-center"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <h2 className="text-4xl font-bold text-primary-300 mb-4">Was kann ich für dich tun? 🤔</h2>
            <p className="text-xl text-wood-300">Lass uns zusammen deine Social Media Präsenz aufbauen!</p>
          </motion.div>

          <div className="mt-16">
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="card interactive-element"
                >
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-500 text-wood-900 mx-auto">
                    <feature.icon className="h-6 w-6" />
                  </div>
                  <h3 className="mt-4 text-xl font-semibold text-center text-primary-300">
                    {feature.title}
                  </h3>
                  <p className="mt-2 text-wood-300 text-center">
                    {feature.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>

      {/* CTA Section */}
      <motion.div 
        className="min-h-screen bg-primary-600 flex items-center"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center py-16">
          <h2 className="text-5xl font-bold text-wood-900 mb-8">
            Ready to rock? 🚀
          </h2>
          <p className="text-2xl text-wood-800 mb-12">
            Lass uns gemeinsam deine Social Media Präsenz auf das nächste Level bringen!
          </p>
          <Link
            to="/login"
            className="inline-flex items-center px-8 py-4 rounded-full text-lg font-medium text-primary-600 bg-wood-100 hover:bg-wood-200 transform transition-all duration-300 hover:scale-105"
          >
            Lass uns loslegen!
            <ChevronRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </motion.div>
    </div>
  );
}