import React, { useState } from 'react';
import { Search, Target, Maximize2, BarChart2, Plus, AlertTriangle, Info, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { useSEOStore, SEOReport } from '../store/seoStore';

export function SeoTools() {
  const { reports } = useSEOStore();
  const [url, setUrl] = useState('');

  const tools = [
    {
      name: 'Keyword Research',
      description: 'Find the best keywords for your content',
      icon: Search,
      status: 'coming-soon'
    },
    {
      name: 'Content Optimization',
      description: 'Optimize your content for better rankings',
      icon: Target,
      status: 'coming-soon'
    },
    {
      name: 'Competitor Analysis',
      description: 'Track and analyze your competitors',
      icon: BarChart2,
      status: 'coming-soon'
    },
    {
      name: 'Performance Tracking',
      description: 'Monitor your SEO performance',
      icon: Maximize2,
      status: 'coming-soon'
    }
  ];

  const handleAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle URL analysis
    console.log('Analyzing:', url);
    setUrl('');
  };

  return (
    <div>
      <div className="pb-5 border-b border-wood-700">
        <h3 className="text-3xl font-bold text-primary-300">
          SEO Tools
        </h3>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-2">
        {/* SEO Tools Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-wood-800 rounded-lg shadow-lg"
        >
          <div className="p-6">
            <h4 className="text-xl font-semibold text-wood-100 mb-6">Available Tools</h4>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              {tools.map((tool) => (
                <div
                  key={tool.name}
                  className="bg-wood-700 p-4 rounded-lg hover:bg-wood-600 transition-colors group"
                >
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 rounded-lg bg-primary-500/20">
                      <tool.icon className="h-5 w-5 text-primary-400" />
                    </div>
                    <h5 className="font-medium text-wood-100">{tool.name}</h5>
                  </div>
                  <p className="text-wood-300 text-sm">{tool.description}</p>
                  <span className="mt-2 inline-block text-xs text-wood-400">Coming Soon</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Quick Analysis */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-wood-800 rounded-lg shadow-lg"
        >
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-xl font-semibold text-wood-100">Quick Analysis</h4>
              <button className="bg-primary-500 text-wood-900 p-2 rounded-lg hover:bg-primary-400 transition-colors">
                <Plus className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleAnalyze} className="mb-6">
              <div className="flex gap-2">
                <input
                  type="url"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="Enter URL to analyze"
                  className="flex-1 bg-wood-700 text-wood-100 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
                <button
                  type="submit"
                  className="bg-primary-500 text-wood-900 px-4 py-2 rounded-lg hover:bg-primary-400 transition-colors"
                >
                  Analyze
                </button>
              </div>
            </form>

            <div className="space-y-4">
              {reports.map((report) => (
                <div
                  key={report.id}
                  className="bg-wood-700 rounded-lg p-4"
                >
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="font-medium text-wood-100">{report.title}</h5>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      report.score >= 90 ? 'bg-green-500/20 text-green-400' :
                      report.score >= 70 ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-red-500/20 text-red-400'
                    }`}>
                      Score: {report.score}
                    </span>
                  </div>
                  <p className="text-wood-300 text-sm mb-2">{report.url}</p>
                  <div className="space-y-2">
                    {report.issues.map((issue, index) => (
                      <div key={index} className="flex items-start gap-2">
                        {issue.type === 'error' && <AlertTriangle className="h-4 w-4 text-red-400 flex-shrink-0 mt-0.5" />}
                        {issue.type === 'warning' && <AlertTriangle className="h-4 w-4 text-yellow-400 flex-shrink-0 mt-0.5" />}
                        {issue.type === 'info' && <Info className="h-4 w-4 text-blue-400 flex-shrink-0 mt-0.5" />}
                        <p className="text-wood-300 text-sm">{issue.message}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}