import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Settings as SettingsIcon, Twitter, Instagram, Linkedin, Facebook, Trash2 } from 'lucide-react';
import { motion } from 'framer-motion';

interface SocialAccount {
  id: string;
  platform: string;
  account_name: string;
  created_at: string;
}

export function Settings() {
  const { supabase, user } = useAuth();
  const [accounts, setAccounts] = useState<SocialAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const platforms = [
    { name: 'Twitter', icon: Twitter, color: 'bg-blue-400' },
    { name: 'Instagram', icon: Instagram, color: 'bg-pink-500' },
    { name: 'LinkedIn', icon: Linkedin, color: 'bg-blue-600' },
    { name: 'Facebook', icon: Facebook, color: 'bg-blue-500' }
  ];

  useEffect(() => {
    fetchAccounts();
  }, []);

  async function fetchAccounts() {
    try {
      const { data, error } = await supabase
        .from('social_accounts')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setAccounts(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  }

  async function connectAccount(platform: string) {
    // This would typically open OAuth flow
    console.log(`Connecting to ${platform}...`);
  }

  async function disconnectAccount(id: string) {
    try {
      const { error } = await supabase
        .from('social_accounts')
        .delete()
        .match({ id });

      if (error) throw error;
      setAccounts(accounts.filter(account => account.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  }

  return (
    <div>
      <div className="pb-5 border-b border-wood-700">
        <h3 className="text-3xl font-bold text-primary-300">
          Settings
        </h3>
      </div>

      <div className="mt-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-wood-800 rounded-lg shadow-lg"
        >
          <div className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <SettingsIcon className="h-6 w-6 text-primary-400" />
              <h4 className="text-xl font-semibold text-wood-100">
                Connected Accounts
              </h4>
            </div>
            
            {error && (
              <div className="mb-6 bg-red-900/50 border border-red-500 text-red-200 px-4 py-3 rounded">
                {error}
              </div>
            )}

            <div className="space-y-4">
              {accounts.map(account => {
                const platform = platforms.find(p => p.name === account.platform);
                return (
                  <div
                    key={account.id}
                    className="flex items-center justify-between p-4 bg-wood-700 rounded-lg hover:bg-wood-600 transition-colors"
                  >
                    <div className="flex items-center">
                      {platform && (
                        <div className={`${platform.color} p-2 rounded-lg`}>
                          <platform.icon className="h-5 w-5 text-white" />
                        </div>
                      )}
                      <div className="ml-3">
                        <p className="text-wood-100 font-medium">{account.platform}</p>
                        <p className="text-wood-300">@{account.account_name}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => disconnectAccount(account.id)}
                      className="text-wood-400 hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                );
              })}

              {!loading && accounts.length === 0 && (
                <p className="text-wood-300 text-center py-4">
                  No social media accounts connected yet.
                </p>
              )}
            </div>

            <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
              {platforms.map(platform => (
                <button
                  key={platform.name}
                  onClick={() => connectAccount(platform.name)}
                  className="flex items-center justify-center px-4 py-3 rounded-lg bg-wood-700 hover:bg-wood-600 transition-colors text-wood-100"
                >
                  <platform.icon className="h-5 w-5 mr-2" />
                  Connect {platform.name}
                </button>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}