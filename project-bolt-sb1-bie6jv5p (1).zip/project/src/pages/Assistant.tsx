import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export function Assistant() {
  const [message, setMessage] = useState('');
  const [chatHistory, setChatHistory] = useState([
    { type: 'bot' as const, text: "Hey! 👋 Ich bin dein Sicht-Bär! Wie kann ich dir heute helfen?" }
  ]);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatHistory]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    setChatHistory(prev => [...prev, { type: 'user' as const, text: message }]);

    // Simulate AI response
    setTimeout(() => {
      let response = "Das ist eine interessante Frage! ";
      if (message.toLowerCase().includes('post')) {
        response += "Lass uns zusammen einen tollen Post erstellen! Was ist dein Ziel?";
      } else if (message.toLowerCase().includes('analytics')) {
        response += "Ich kann dir helfen, deine Daten zu analysieren und zu verstehen!";
      } else {
        response += "Wie kann ich dir dabei am besten helfen?";
      }
      setChatHistory(prev => [...prev, { type: 'bot' as const, text: response }]);
    }, 1000);

    setMessage('');
  };

  return (
    <div>
      <div className="pb-5 border-b border-wood-700">
        <h3 className="text-3xl font-bold text-primary-300">
          AI Assistant
        </h3>
      </div>

      <div className="mt-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Bear Image Section */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="hidden lg:flex items-center justify-center"
          >
            <img
              src="https://i.imgur.com/XxfPmtQ.png"
              alt="Sicht-Bär Character"
              className="max-w-md w-full h-auto"
              style={{
                filter: 'drop-shadow(0 0 20px rgba(255, 179, 0, 0.3))'
              }}
            />
          </motion.div>

          {/* Chat Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-wood-800 rounded-lg shadow-lg overflow-hidden"
          >
            <div className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <Bot className="h-8 w-8 text-primary-400" />
                <div>
                  <h4 className="text-xl font-semibold text-wood-100">Sicht-Bär Assistant</h4>
                  <p className="text-wood-300">Dein KI-gestützter Social Media Experte</p>
                </div>
              </div>

              <div 
                ref={chatContainerRef}
                className="h-[500px] overflow-y-auto bg-wood-700/50 rounded-lg p-4 mb-4"
              >
                <AnimatePresence>
                  {chatHistory.map((msg, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'} mb-4`}
                    >
                      {msg.type === 'bot' && (
                        <div className="w-8 h-8 rounded-full overflow-hidden mr-2 flex-shrink-0">
                          <img
                            src="https://i.imgur.com/XxfPmtQ.png"
                            alt="Sicht-Bär"
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                      <div
                        className={`rounded-lg px-4 py-2 max-w-[80%] ${
                          msg.type === 'user'
                            ? 'bg-primary-500 text-wood-900'
                            : 'bg-wood-600 text-wood-100'
                        }`}
                      >
                        {msg.text}
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              <form onSubmit={handleSubmit} className="flex gap-2">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="flex-1 bg-wood-700 text-wood-100 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                  placeholder="Schreib mir eine Nachricht..."
                />
                <button
                  type="submit"
                  className="bg-primary-500 text-wood-900 rounded-lg px-4 py-2 hover:bg-primary-400 transition-colors flex items-center gap-2"
                >
                  <Send className="h-5 w-5" />
                  Senden
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}