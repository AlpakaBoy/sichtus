import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Activity,
  Users,
  TrendingUp,
  Calendar,
  ArrowUp,
  ArrowDown,
  Globe,
  Clock,
  MousePointer,
  RefreshCw,
  Plus,
  Twitter,
  Instagram,
  Linkedin,
  Facebook,
  Link as LinkIcon,
  Settings
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';

export function Dashboard() {
  const [showAddSocial, setShowAddSocial] = useState(false);
  const [showAddUrl, setShowAddUrl] = useState(false);

  const socialPlatforms = [
    { name: 'Twitter', icon: Twitter, color: 'bg-blue-400' },
    { name: 'Instagram', icon: Instagram, color: 'bg-pink-500' },
    { name: 'LinkedIn', icon: Linkedin, color: 'bg-blue-600' },
    { name: 'Facebook', icon: Facebook, color: 'bg-blue-500' }
  ];

  const connectedAccounts = [
    { platform: 'Twitter', username: '@sichtbaer', followers: '12.5K' },
    { platform: 'Instagram', username: '@sicht.baer', followers: '25.8K' }
  ];

  const trackedUrls = [
    { url: 'https://sichtbaer.de/blog', visits: '1.2K', engagement: '85%' },
    { url: 'https://sichtbaer.de/shop', visits: '3.5K', engagement: '92%' }
  ];

  const stats = [
    {
      name: 'Total Posts',
      stat: '71,897',
      icon: Calendar,
      change: '12%',
      changeType: 'increase',
    },
    {
      name: 'Engagement Rate',
      stat: '58.16%',
      icon: Activity,
      change: '2.02%',
      changeType: 'increase',
    },
    {
      name: 'Followers',
      stat: '24,500',
      icon: Users,
      change: '4.05%',
      changeType: 'increase',
    },
    {
      name: 'Growth Rate',
      stat: '24.57%',
      icon: TrendingUp,
      change: '3.2%',
      changeType: 'decrease',
    },
  ];

  return (
    <div>
      <div className="pb-5 border-b border-wood-700">
        <h3 className="text-3xl font-bold text-primary-300">
          Willkommen zurück! 👋
        </h3>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-2">
        {/* Social Media Accounts */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-wood-800 rounded-lg shadow-lg overflow-hidden"
        >
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h4 className="text-xl font-semibold text-wood-100">
                Social Media Accounts
              </h4>
              <button
                onClick={() => setShowAddSocial(!showAddSocial)}
                className="bg-primary-500 text-wood-900 p-2 rounded-lg hover:bg-primary-400 transition-colors"
              >
                <Plus className="h-5 w-5" />
              </button>
            </div>

            {showAddSocial && (
              <div className="mb-6 grid grid-cols-2 gap-4">
                {socialPlatforms.map(platform => (
                  <button
                    key={platform.name}
                    className="flex items-center justify-center p-3 rounded-lg bg-wood-700 hover:bg-wood-600 transition-colors"
                  >
                    <platform.icon className="h-5 w-5 mr-2" />
                    <span className="text-wood-100">Add {platform.name}</span>
                  </button>
                ))}
              </div>
            )}

            <div className="space-y-4">
              {connectedAccounts.map(account => (
                <div
                  key={account.username}
                  className="bg-wood-700 rounded-lg p-4 flex items-center justify-between"
                >
                  <div className="flex items-center">
                    {account.platform === 'Twitter' && <Twitter className="h-5 w-5 text-blue-400 mr-3" />}
                    {account.platform === 'Instagram' && <Instagram className="h-5 w-5 text-pink-500 mr-3" />}
                    <div>
                      <p className="text-wood-100 font-medium">{account.username}</p>
                      <p className="text-wood-300 text-sm">{account.followers} followers</p>
                    </div>
                  </div>
                  <button className="text-wood-300 hover:text-wood-100 transition-colors">
                    <Settings className="h-5 w-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Tracked URLs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-wood-800 rounded-lg shadow-lg overflow-hidden"
        >
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h4 className="text-xl font-semibold text-wood-100">
                Tracked URLs
              </h4>
              <button
                onClick={() => setShowAddUrl(!showAddUrl)}
                className="bg-primary-500 text-wood-900 p-2 rounded-lg hover:bg-primary-400 transition-colors"
              >
                <Plus className="h-5 w-5" />
              </button>
            </div>

            {showAddUrl && (
              <div className="mb-6">
                <div className="flex gap-2">
                  <input
                    type="url"
                    placeholder="Enter URL to track"
                    className="flex-1 bg-wood-700 text-wood-100 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                  <button className="bg-primary-500 text-wood-900 px-4 py-2 rounded-lg hover:bg-primary-400 transition-colors">
                    Add URL
                  </button>
                </div>
              </div>
            )}

            <div className="space-y-4">
              {trackedUrls.map(url => (
                <div
                  key={url.url}
                  className="bg-wood-700 rounded-lg p-4 flex items-center justify-between"
                >
                  <div className="flex items-center">
                    <LinkIcon className="h-5 w-5 text-primary-400 mr-3" />
                    <div>
                      <p className="text-wood-100 font-medium">{url.url}</p>
                      <p className="text-wood-300 text-sm">{url.visits} visits • {url.engagement} engagement</p>
                    </div>
                  </div>
                  <button className="text-wood-300 hover:text-wood-100 transition-colors">
                    <Settings className="h-5 w-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Quick Stats */}
      <div className="mt-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-wood-800 rounded-lg shadow-lg overflow-hidden"
        >
          <div className="p-6">
            <h4 className="text-xl font-semibold text-wood-100 mb-6">
              Quick Stats
            </h4>
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {stats.map((item) => (
                <div
                  key={item.name}
                  className="bg-wood-700 rounded-lg p-4"
                >
                  <div className="flex items-center">
                    <div className="p-2 rounded-lg bg-primary-500/20 text-primary-400">
                      <item.icon className="h-5 w-5" />
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium text-wood-300">{item.name}</p>
                      <div className="flex items-baseline">
                        <p className="text-lg font-semibold text-wood-100">{item.stat}</p>
                        <span className={`ml-2 text-sm font-medium ${item.changeType === 'increase' ? 'text-green-400' : 'text-red-400'}`}>
                          {item.change}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}