import { create } from 'zustand';

export interface SEOReport {
  id: string;
  url: string;
  title: string;
  description: string;
  score: number;
  issues: SEOIssue[];
  lastChecked: string;
}

export interface SEOIssue {
  type: 'error' | 'warning' | 'info';
  message: string;
  priority: number;
}

interface SEOStore {
  reports: SEOReport[];
}

// Dummy SEO data
const dummyReports: SEOReport[] = [
  {
    id: '1',
    url: 'https://example.com/blog/social-media-tips',
    title: 'Top Social Media Tips for 2024',
    description: 'Learn the best social media strategies for growing your audience in 2024.',
    score: 85,
    issues: [
      {
        type: 'warning',
        message: 'Meta description could be more descriptive',
        priority: 2
      },
      {
        type: 'info',
        message: 'Consider adding more internal links',
        priority: 3
      }
    ],
    lastChecked: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '2',
    url: 'https://example.com/services',
    title: 'Our Social Media Services',
    description: 'Professional social media management and strategy services.',
    score: 92,
    issues: [
      {
        type: 'info',
        message: 'Image alt tags could be more descriptive',
        priority: 3
      }
    ],
    lastChecked: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
  }
];

export const useSEOStore = create<SEOStore>(() => ({
  reports: dummyReports
}));