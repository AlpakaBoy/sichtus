import { create } from 'zustand';

export interface Draft {
  id: string;
  title: string;
  content: string;
  platform: string;
  priority: number;
  createdAt: string;
  scheduledFor: string | null;
  status: 'draft' | 'scheduled' | 'published';
}

interface ContentStore {
  drafts: Draft[];
  addDraft: (draft: Draft) => void;
  updateDraft: (id: string, updates: Partial<Draft>) => void;
  deleteDraft: (id: string) => void;
  reorderDrafts: (drafts: Draft[]) => void;
  scheduleDraft: (id: string, date: string) => void;
}

// Dummy data for demonstration
const dummyDrafts: Draft[] = [
  {
    id: '1',
    title: 'New Product Launch',
    content: '🎉 Exciting news! We\'re launching something amazing...',
    platform: 'Instagram',
    priority: 1,
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    scheduledFor: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'scheduled'
  },
  {
    id: '2',
    title: 'Weekly Tips Thread',
    content: '🧵 Here are this week\'s top social media tips...',
    platform: 'Twitter',
    priority: 2,
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    scheduledFor: null,
    status: 'draft'
  },
  {
    id: '3',
    title: 'Customer Success Story',
    content: '🌟 Meet our amazing customer who achieved...',
    platform: 'LinkedIn',
    priority: 3,
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    scheduledFor: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'scheduled'
  },
  {
    id: '4',
    title: 'Behind the Scenes',
    content: '📸 Take a peek at what goes on behind...',
    platform: 'Instagram',
    priority: 4,
    createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    scheduledFor: null,
    status: 'draft'
  }
];

export const useContentStore = create<ContentStore>((set) => ({
  drafts: dummyDrafts,
  addDraft: (draft) => set((state) => ({ drafts: [draft, ...state.drafts] })),
  updateDraft: (id, updates) => set((state) => ({
    drafts: state.drafts.map((draft) =>
      draft.id === id ? { ...draft, ...updates } : draft
    ),
  })),
  deleteDraft: (id) => set((state) => ({
    drafts: state.drafts.filter((draft) => draft.id !== id),
  })),
  reorderDrafts: (drafts) => set({ drafts }),
  scheduleDraft: (id, date) => set((state) => ({
    drafts: state.drafts.map((draft) =>
      draft.id === id
        ? { ...draft, scheduledFor: date, status: 'scheduled' }
        : draft
    ),
  })),
}));