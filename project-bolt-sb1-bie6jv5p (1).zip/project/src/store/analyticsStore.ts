import { create } from 'zustand';

export interface AnalyticsData {
  platform: string;
  reach: number;
  engagement: number;
  followers: number;
  growth: number;
  posts: number;
  likes: number;
  comments: number;
  shares: number;
}

interface AnalyticsStore {
  data: Record<string, AnalyticsData>;
}

// Dummy analytics data
const dummyData: Record<string, AnalyticsData> = {
  Instagram: {
    platform: 'Instagram',
    reach: 150000,
    engagement: 4.5,
    followers: 25000,
    growth: 12.3,
    posts: 450,
    likes: 75000,
    comments: 3200,
    shares: 1500
  },
  Twitter: {
    platform: 'Twitter',
    reach: 200000,
    engagement: 3.2,
    followers: 18000,
    growth: 8.7,
    posts: 890,
    likes: 45000,
    comments: 2800,
    shares: 4200
  },
  LinkedIn: {
    platform: 'LinkedIn',
    reach: 80000,
    engagement: 5.8,
    followers: 12000,
    growth: 15.4,
    posts: 220,
    likes: 28000,
    comments: 1500,
    shares: 3100
  },
  Facebook: {
    platform: 'Facebook',
    reach: 250000,
    engagement: 3.9,
    followers: 35000,
    growth: 6.8,
    posts: 380,
    likes: 92000,
    comments: 4800,
    shares: 5600
  }
};

export const useAnalyticsStore = create<AnalyticsStore>(() => ({
  data: dummyData
}));