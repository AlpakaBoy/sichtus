import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { ContentPlanning } from './pages/ContentPlanning';
import { ContentProduction } from './pages/ContentProduction';
import { Analytics } from './pages/Analytics';
import { SeoTools } from './pages/SeoTools';
import { Assistant } from './pages/Assistant';
import { Settings } from './pages/Settings';
import { LandingPage } from './pages/LandingPage';
import { Login } from './pages/Login';
import { AuthProvider, useAuth } from './contexts/AuthContext';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  return user ? <>{children}</> : <Navigate to="/login" />;
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<Login />} />
          <Route
            path="/dashboard"
            element={
              <PrivateRoute>
                <Layout />
              </PrivateRoute>
            }
          >
            <Route index element={<Dashboard />} />
            <Route path="content" element={<ContentPlanning />} />
            <Route path="production" element={<ContentProduction />} />
            <Route path="analytics" element={<Analytics />} />
            <Route path="seo" element={<SeoTools />} />
            <Route path="assistant" element={<Assistant />} />
            <Route path="settings" element={<Settings />} />
          </Route>
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;