/// <reference types="vite/client" />

declare namespace JSX {
  interface IntrinsicElements {
    'model-viewer': ModelViewerElement;
  }
}

interface ModelViewerElement extends HTMLElement {
  src: string;
  alt: string;
  poster?: string;
  loading?: 'auto' | 'lazy' | 'eager';
  reveal?: 'auto' | 'interaction' | 'manual';
  'camera-controls'?: boolean;
  'auto-rotate'?: boolean;
  'rotation-per-second'?: string;
  'interaction-prompt'?: 'auto' | 'when-focused' | 'none';
  'interaction-prompt-style'?: 'basic' | 'wiggle';
  'interaction-prompt-threshold'?: number;
  'orbit-sensitivity'?: number;
  'min-camera-orbit'?: string;
  'max-camera-orbit'?: string;
  'camera-target'?: string;
  'field-of-view'?: string;
  'min-field-of-view'?: string;
  'max-field-of-view'?: string;
  exposure?: number;
  'shadow-intensity'?: number;
  'shadow-softness'?: number;
  'animation-name'?: string;
  'animation-crossfade-duration'?: number;
  'variant-name'?: string;
  orientation?: string;
  scale?: string;
  'environment-image'?: string;
  'skybox-image'?: string;
  'camera-orbit'?: string;
  'ar'?: boolean;
  'ar-modes'?: string;
  'ar-scale'?: 'auto' | 'fixed';
  'ar-placement'?: 'floor' | 'wall';
  'ios-src'?: string;
  'touch-action'?: string;
  'disable-zoom'?: boolean;
  'disable-tap'?: boolean;
  'disable-pan'?: boolean;
  'disable-scroll'?: boolean;
}