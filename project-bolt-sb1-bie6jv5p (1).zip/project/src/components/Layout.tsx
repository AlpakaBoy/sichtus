import React, { useState } from 'react';
import { Outlet, Link, useLocation, Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import {
  LayoutDashboard,
  Calendar,
  PenTool,
  BarChart2,
  Search,
  Bot,
  LogOut,
  Settings as SettingsIcon,
  Menu,
  X,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { BearAssistant } from './BearAssistant';

export function Layout() {
  const { user, signOut } = useAuth();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  const navigation = [
    { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    { name: 'Content Planning', href: '/dashboard/content', icon: Calendar },
    { name: 'Content Production', href: '/dashboard/production', icon: PenTool },
    { name: 'Analytics', href: '/dashboard/analytics', icon: BarChart2 },
    { name: 'SEO Tools', href: '/dashboard/seo', icon: Search },
    { name: 'AI Assistant', href: '/dashboard/assistant', icon: Bot },
    { name: 'Settings', href: '/dashboard/settings', icon: SettingsIcon },
  ];

  const getBearMessage = () => {
    const path = location.pathname;
    switch (path) {
      case '/dashboard':
        return "Willkommen im Dashboard! Hier siehst du alle wichtigen Kennzahlen auf einen Blick. 📊";
      case '/dashboard/content':
        return "Lass uns deinen Content planen! Ich helfe dir dabei, den perfekten Zeitplan zu erstellen. 📝";
      case '/dashboard/production':
        return "Hier können wir zusammen tolle Inhalte erstellen! Sag mir einfach, was du brauchst. ✨";
      case '/dashboard/analytics':
        return "Hier findest du alle wichtigen Analytics-Daten. Brauchst du Hilfe bei der Interpretation? 📈";
      case '/dashboard/seo':
        return "SEO ist wichtig! Ich helfe dir, deine Inhalte zu optimieren. 🔍";
      case '/dashboard/assistant':
        return "Ich bin dein KI-Assistent! Wie kann ich dir heute helfen? 🤖";
      case '/dashboard/settings':
        return "Hier kannst du alle wichtigen Einstellungen vornehmen. Brauchst du Hilfe? ⚙️";
      default:
        return "Hey! Wie kann ich dir helfen? 👋";
    }
  };

  return (
    <div className="min-h-screen bg-wood-900">
      <div className="flex h-screen">
        {/* Mobile menu button */}
        <div className="md:hidden fixed top-4 right-4 z-50">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 rounded-md bg-wood-800 text-wood-100 hover:bg-wood-700 focus:outline-none focus:ring-2 focus:ring-primary-500"
          >
            {isMobileMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>

        {/* Mobile menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween' }}
              className="fixed inset-0 z-40 md:hidden bg-wood-900"
            >
              <div className="flex flex-col h-full pt-16 pb-6 bg-wood-800">
                <div className="flex items-center justify-center mb-8">
                  <img
                    className="h-12 w-auto"
                    src="https://i.imgur.com/z2v9SfQ.png"
                    alt="SichtBär"
                  />
                  <span className="ml-2 text-xl font-semibold text-wood-100">
                    SichtBär
                  </span>
                </div>
                <nav className="flex-1 px-4 space-y-2">
                  {navigation.map((item) => {
                    const isActive = location.pathname === item.href;
                    return (
                      <Link
                        key={item.name}
                        to={item.href}
                        onClick={() => setIsMobileMenuOpen(false)}
                        className={`flex items-center px-4 py-3 text-base font-medium rounded-md transition-colors ${
                          isActive
                            ? 'bg-primary-500/20 text-primary-400'
                            : 'text-wood-300 hover:bg-wood-700 hover:text-primary-300'
                        }`}
                      >
                        <item.icon
                          className={`mr-3 h-5 w-5 ${
                            isActive
                              ? 'text-primary-400'
                              : 'text-wood-400 group-hover:text-primary-300'
                          }`}
                        />
                        {item.name}
                      </Link>
                    );
                  })}
                </nav>
                <div className="px-4 mt-6">
                  <button
                    onClick={signOut}
                    className="flex items-center w-full px-4 py-3 text-base font-medium text-wood-300 hover:text-primary-300 transition-colors rounded-md hover:bg-wood-700"
                  >
                    <LogOut className="mr-3 h-5 w-5" />
                    Sign out
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Sidebar for desktop */}
        <div className="hidden md:flex md:w-64 md:flex-col">
          <div className="flex flex-col flex-grow pt-5 overflow-y-auto bg-wood-800 border-r border-wood-700">
            <div className="flex items-center flex-shrink-0 px-4">
              <img
                className="h-12 w-auto"
                src="https://i.imgur.com/z2v9SfQ.png"
                alt="SichtBär"
              />
              <span className="ml-2 text-xl font-semibold text-wood-100">
                SichtBär
              </span>
            </div>
            <div className="mt-5 flex-grow flex flex-col">
              <nav className="flex-1 px-2 space-y-1">
                {navigation.map((item) => {
                  const isActive = location.pathname === item.href;
                  return (
                    <Link
                      key={item.name}
                      to={item.href}
                      className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors ${
                        isActive
                          ? 'bg-primary-500/20 text-primary-400'
                          : 'text-wood-300 hover:bg-wood-700 hover:text-primary-300'
                      }`}
                    >
                      <item.icon
                        className={`mr-3 h-5 w-5 ${
                          isActive
                            ? 'text-primary-400'
                            : 'text-wood-400 group-hover:text-primary-300'
                        }`}
                      />
                      {item.name}
                    </Link>
                  );
                })}
              </nav>
            </div>
            <div className="flex-shrink-0 flex border-t border-wood-700 p-4">
              <button
                onClick={signOut}
                className="flex items-center w-full text-sm font-medium text-wood-300 hover:text-primary-300 transition-colors"
              >
                <LogOut className="mr-3 h-5 w-5" />
                Sign out
              </button>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="flex flex-col flex-1 overflow-hidden">
          <main className="flex-1 relative overflow-y-auto focus:outline-none bg-wood-900">
            <div className="py-6">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
                <Outlet />
              </div>
            </div>
          </main>
        </div>

        {/* Bear Assistant */}
        <BearAssistant initialMessage={getBearMessage()} />
      </div>
    </div>
  );
}