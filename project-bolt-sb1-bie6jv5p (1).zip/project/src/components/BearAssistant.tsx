import React, { useState, useRef, useEffect } from 'react';
import { Send, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface BearAssistantProps {
  initialMessage: string;
}

export function BearAssistant({ initialMessage }: BearAssistantProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [chatMessage, setChatMessage] = useState('');
  const [chatHistory, setChatHistory] = useState([
    { type: 'bot' as const, text: initialMessage }
  ]);
  const [unreadCount, setUnreadCount] = useState(1);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatHistory]);

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;

    setChatHistory(prev => [...prev, { type: 'user' as const, text: chatMessage }]);

    setTimeout(() => {
      let response = "Das ist eine super Frage! ";
      if (chatMessage.toLowerCase().includes('hilfe')) {
        response += "Ich helfe dir gerne! Was möchtest du genau wissen?";
      } else if (chatMessage.toLowerCase().includes('danke')) {
        response += "Gerne! Ich bin immer für dich da! 🐻";
      } else {
        response += "Lass uns das gemeinsam anschauen! Was möchtest du als nächstes tun?";
      }
      setChatHistory(prev => [...prev, { type: 'bot' as const, text: response }]);
      if (!isOpen) {
        setUnreadCount(prev => prev + 1);
      }
    }, 1000);

    setChatMessage('');
  };

  const toggleChat = () => {
    setIsOpen(!isOpen);
    if (!isOpen) {
      setUnreadCount(0);
    }
  };

  return (
    <div className="chat-widget">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="chat-widget-bubble"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <img
                  src="https://i.imgur.com/z2v9SfQ.png"
                  alt="Sicht-Bär"
                  className="w-12 h-12 mr-2"
                />
                <span className="font-medium text-wood-100">Sicht-Bär Assistant</span>
              </div>
              <button
                onClick={toggleChat}
                className="text-wood-400 hover:text-wood-300 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div ref={chatContainerRef} className="chat-container">
              <AnimatePresence>
                {chatHistory.map((msg, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`rounded-lg px-4 py-2 max-w-[80%] ${
                        msg.type === 'user'
                          ? 'bg-primary-500 text-wood-900'
                          : 'bg-wood-700 text-wood-100'
                      }`}
                    >
                      {msg.text}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            <form onSubmit={handleChatSubmit} className="mt-4 flex gap-2">
              <input
                type="text"
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                placeholder="Schreib mir eine Nachricht..."
                className="flex-1 bg-wood-700 text-wood-100 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
              <button
                type="submit"
                className="bg-primary-500 text-wood-900 rounded-lg p-2 hover:bg-primary-400 transition-colors"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={toggleChat}
        className="chat-widget-toggle relative"
      >
        {!isOpen && unreadCount > 0 && (
          <span className="chat-notification">{unreadCount}</span>
        )}
        {isOpen ? (
          <X className="w-6 h-6" />
        ) : (
          <img
            src="https://i.imgur.com/z2v9SfQ.png"
            alt="Sicht-Bär"
            className="w-8 h-8"
          />
        )}
      </motion.button>
    </div>
  );
}