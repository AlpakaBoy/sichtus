import { createClient } from '@supabase/supabase-js';
import { config } from 'dotenv';
import { logger } from './logger';

// Load environment variables
config();

const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  logger.error('Missing required Supabase environment variables');
  throw new Error('Missing required Supabase environment variables. Please check your .env file.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true
  }
});

// Test the connection
supabase.auth.getSession().catch(error => {
  logger.error('Failed to connect to Supabase:', error);
  throw new Error('Failed to connect to Supabase. Please check your credentials.');
});