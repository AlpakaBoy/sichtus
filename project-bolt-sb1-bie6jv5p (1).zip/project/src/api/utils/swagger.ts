import { Express } from 'express';
import swaggerJsdoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Sicht-Bär API',
      version: '1.0.0',
      description: 'API documentation for Sicht-Bär social media management platform'
    },
    servers: [
      {
        url: process.env.NODE_ENV === 'production' 
          ? 'https://api.sicht-baer.de'
          : 'http://localhost:3000',
        description: process.env.NODE_ENV === 'production' ? 'Production server' : 'Development server'
      }
    ]
  },
  apis: ['./src/api/routes/*.ts']
};

export const setupSwagger = (app: Express) => {
  const specs = swaggerJsdoc(options);
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs));
};