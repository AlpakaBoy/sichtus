import { Express } from 'express';
import { postsRouter } from './posts';
import { analyticsRouter } from './analytics';
import { seoRouter } from './seo';
import { socialAccountsRouter } from './socialAccounts';

export const setupRoutes = (app: Express) => {
  app.use('/api/posts', postsRouter);
  app.use('/api/analytics', analyticsRouter);
  app.use('/api/seo', seoRouter);
  app.use('/api/social-accounts', socialAccountsRouter);
};