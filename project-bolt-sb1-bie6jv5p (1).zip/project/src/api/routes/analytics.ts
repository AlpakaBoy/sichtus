import { Router } from 'express';
import { auth } from '../middleware/auth';
import { supabase } from '../utils/supabase';

const router = Router();

/**
 * @swagger
 * /api/analytics:
 *   get:
 *     summary: Get analytics data
 *     tags: [Analytics]
 *     security:
 *       - bearerAuth: []
 */
router.get('/', auth, async (req, res, next) => {
  try {
    const { data, error } = await supabase
      .from('analytics')
      .select('*')
      .order('date', { ascending: false });

    if (error) throw error;
    res.json(data);
  } catch (error) {
    next(error);
  }
});

export const analyticsRouter = router;