import { Router } from 'express';
import { auth } from '../middleware/auth';
import { supabase } from '../utils/supabase';

const router = Router();

/**
 * @swagger
 * /api/social-accounts:
 *   get:
 *     summary: Get social media accounts
 *     tags: [Social Accounts]
 *     security:
 *       - bearerAuth: []
 */
router.get('/', auth, async (req, res, next) => {
  try {
    const { data, error } = await supabase
      .from('social_accounts')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    res.json(data);
  } catch (error) {
    next(error);
  }
});

export const socialAccountsRouter = router;