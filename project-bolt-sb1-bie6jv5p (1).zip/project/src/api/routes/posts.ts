import { Router } from 'express';
import { z } from 'zod';
import { auth } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { supabase } from '../utils/supabase';

const router = Router();

const postSchema = z.object({
  body: z.object({
    title: z.string().min(1),
    content: z.string().min(1),
    platform: z.string(),
    scheduledFor: z.string().datetime().optional(),
    status: z.enum(['draft', 'scheduled', 'published'])
  })
});

/**
 * @swagger
 * /api/posts:
 *   get:
 *     summary: Get all posts
 *     tags: [Posts]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of posts
 */
router.get('/', auth, async (req, res, next) => {
  try {
    const { data, error } = await supabase
      .from('posts')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    res.json(data);
  } catch (error) {
    next(error);
  }
});

/**
 * @swagger
 * /api/posts:
 *   post:
 *     summary: Create a new post
 *     tags: [Posts]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Post'
 */
router.post('/', auth, validate(postSchema), async (req, res, next) => {
  try {
    const { data, error } = await supabase
      .from('posts')
      .insert([{ ...req.body, user_id: req.user?.id }])
      .select()
      .single();

    if (error) throw error;
    res.status(201).json(data);
  } catch (error) {
    next(error);
  }
});

export const postsRouter = router;