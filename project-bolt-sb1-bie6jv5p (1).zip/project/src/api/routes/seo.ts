import { Router } from 'express';
import { auth } from '../middleware/auth';
import { supabase } from '../utils/supabase';

const router = Router();

/**
 * @swagger
 * /api/seo/reports:
 *   get:
 *     summary: Get SEO reports
 *     tags: [SEO]
 *     security:
 *       - bearerAuth: []
 */
router.get('/reports', auth, async (req, res, next) => {
  try {
    const { data, error } = await supabase
      .from('seo_reports')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    res.json(data);
  } catch (error) {
    next(error);
  }
});

export const seoRouter = router;